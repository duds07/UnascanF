
DROP INDEX idx_scan_results_disease;
DROP INDEX idx_scan_results_created_at;
DROP TABLE scan_results;
